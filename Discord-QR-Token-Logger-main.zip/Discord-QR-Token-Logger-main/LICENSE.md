# 📝 License

The actual repository is _unlicensed_, it mean **all rights are reserved**. You cannot modify or redistribute this code without **explicit** permission from the copyright [holders](https://github.com/9P9/Discord-QR-Token-Logger/graphs/contributors). 

_Violating this rule may lead our intervention according to the [Github Terms of Service — User-Generated Content — Section D.3](https://docs.github.com/en/site-policy/github-terms/github-terms-of-service#3-ownership-of-content-right-to-post-and-license-grants) using the [Content Removal Policies — DMCA Takedown Policy](https://docs.github.com/en/site-policy/content-removal-policies/dmca-takedown-policy#what-is-the-dmca)_.
