<h4>⚠️ This repository has been archived and is no longer maintained. ⚠️</h4>

# Discord QR Token Logger

[![forthebadge](https://raw.githubusercontent.com/9P9/Discord-QR-Token-Logger/f0df606d3e95043c7fbc67babc3ec6f2dec5922e/.github/made-by-mouadessalim.svg)](https://github.com/mouadessalim)


![GitHub contributors](https://img.shields.io/github/contributors/9P9/Discord-QR-Token-Logger)
[![PRs Welcome](https://img.shields.io/badge/PRs-welcome-brightgreen.svg?style=shields)](http://makeapullrequest.com)
![GitHub issues](https://img.shields.io/github/issues/9P9/Discord-QR-Token-Logger)
![GitHub pull requests](https://img.shields.io/github/issues-pr/9P9/Discord-QR-Token-Logger)
![Maintenance](https://img.shields.io/maintenance/no/2023)
![GitHub commit activity](https://img.shields.io/github/commit-activity/m/9P9/Discord-QR-Token-Logger)

A python script that generates a scam nitro QR code which can grab a victim's authentication token if scanned. Developed to show how social engineering is performed.

*If you're interested in knowing the powerlevel configuration to get this prompt, you can contact me [here](https://mouadessalim.xyz/#contact).*

![Discord QR Token Grabber](https://user-images.githubusercontent.com/38190847/187040712-92f4c796-c655-47a2-abb2-7f4519d1dab7.png)

<p align="center">
<i>Love the tool? Please consider <strong>donating</strong> 💸 to help it improve!</i>
</p>

<p align="center">
<a href='https://ko-fi.com/mouadessalim' target='_blank'><img height='30' width="115" src='https://cdn.ko-fi.com/cdn/kofi3.png?v=2' alt='Buy Coffee for mouadessalim' />
</a>
<a href="https://www.buymeacoffee.com/mouadessalim" target="_blank"><img src="https://cdn.buymeacoffee.com/buttons/default-orange.png" alt="Buy Me A Coffee" height="30" width="115" style="border-radius:1px" />
</p>

## ❗ Disclaimer
- **For Educational Purposes Only**
- **We decline any responsability in case of misuse of this code.**

# 📖 Table of contents

- [Usage](#-usage)
  - [Without Discord features](#without-discord-webhook)
  - [With Discord features](#with-discord-webhook)
- [Installation](#-installation)
  - [Dependencies](#dependencies)
  - [Supported Platforms](#supported-platforms)
- [Contributing](#contributing)
  - [Authors](#authors-)
- [License](#-license)
- [Other Project](#-other-projects)

# 📈 Usage

To use the script, run `pip install -r requirements.txt` if needed, then run `main.py`. The scam image will appear as `discord_gift.png` in the directory. 

> ⚠️ __The Qr generated image is available for only `2 min`!__ ⚠️

There are two ways to use the script:

### Without Discord Webhook

Without a Discord Webhook, you can only get target token. You must enter `n` when prompted.

<img src="https://user-images.githubusercontent.com/38190847/187074516-29a22055-96a0-40f9-9d79-8a69834ab039.png" width="500">

### With Discord Webhook

To use a Discord Webhook you must enter `y` when prompted.

<img src="https://user-images.githubusercontent.com/38190847/187074586-d5c0a8f5-c96b-45bb-ac96-42550c2f1ae4.png" width="500">

With a Discord Webhook, you will be able to get much more target information. The target information shown includes:

- User token informations :
  - 👑 Username
  - 🆔 User ID
  - 📧 Mail 
  - 📞 Phone 
  - 🤑 Nitro 
- Payment info :
  - 💳 Brand (Visa / Mastecard / PayPal)
  - ℹ/📩 Last 4 digits / PayPal mail
  - 📅 Expiration
- Billing adress :
  - 📛 Name
  - 🏠 1️⃣ Address Line 1
  - 🏠 2️⃣ Address Line 2
  - 🏳 Country
  - 🚩 State
  - 🏙 City
  - 📮 Postal code

# 🛠 Installation

For installation, there are a few requirements. You must follow these steps to avoid all python interpreter errors.

## Dependencies

- Chrome: **be sure to have the latest version**.
- Python 3.9+
- Python Modules (launch `pip install -r requirements.txt`)
- GTK 3 Runtime ([Download here](https://github.com/tschoonj/GTK-for-Windows-Runtime-Environment-Installer/releases))

After installing all dependencies, you can start the script 🥳.

## Supported Platforms
- Windows 11 - `supported but not tested`
- Windows 10 - `supported and tested`
- Windows 8 - `supported but not tested`
- Windows 7 - `supported but not tested`

# ✨Contributing

Your contributions are always welcome! If you contribute we will show your account in this README! 

_Please have a look at the [contribution guidelines](CONTRIBUTING.md) first._ 🎉

## Authors ❤

<a href="https://github.com/9P9/Discord-QR-Token-Logger/graphs/contributors">
  <img src="https://contrib.rocks/image?repo=9P9/Discord-QR-Token-Logger" />
</a>
<br>
<br>

> **Working on your first Pull Request?** You can learn how from this *free* series [How to Contribute to an Open Source Project on GitHub](https://kcd.im/pull-request)
